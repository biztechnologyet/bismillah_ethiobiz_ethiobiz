import frappe
from frappe.model.document import Document

class SalonStylistService(Document):
    pass

